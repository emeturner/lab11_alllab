<!DOCTYPE HTML>
<html>
<body>
<?php
<form action="welcome.php" method="post">
Name: <input type="text" name="Name"><br>
E-mail: <input type="text" name="E-mail"><br>
<input type="submit">
</php>
</form>

</body>
</html>
