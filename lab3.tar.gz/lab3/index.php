<!DOCTYPE>
<html>
<head>
<style>
a:link, a:visited {
    background-color: black;
    color: white;
    border: 5px solid red;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}

a:hover, a:active {
    background-color: green;
    color: white;
}
</style>
</head>

<body background="4.jpg" style="width:1250px;height:800px;">

<br><br><br><br><br>

<center><h1>MANCHESTER UNITED</h1>

<br>
<center><img src="3.jpg" alt="Mountain View" style="width:304px;height:228px;"></center>

<br>
<center><iframe src="http://free.timeanddate.com/clock/i53q4ilj/n122/tluk/fs20/fcfff/tcf00/pcf00/ftbi/bas5/tt0/th2" frameborder="0" width="406" height="36"></iframe>
<br>
<p><strong><a href="http://www.manutd.com/">MU Official Website </a>---This is a EXTERNAL link to Manchester United's website</strong></p>
<p><strong><a href="https://www.facebook.com/manchesterunited/?ref=ts&fref=ts">Facebook page</a>---This is a INTERNAL link to Manchester United's Facebook page</strong></p>

<br><br>
<p> <strong>  <a href="file:///var/www/html/lab3/page1.html">1.HOME PAGE</a>  <a href="file:///var/www/html/lab3/page2.html">2.HISTORY</a>   <a href="file:///var/www/html/lab3/page3.html">3.GALLERIES</a>   <a href="file:///var/www/html/lab3/page4.html">4.GAMES & HIGHLIGHTS</a>   <a href="file:///var/www/html/lab3/page5.html">5.2016 TEAM SQUAD</a>  </strong></p>


<p>For Further Informations or Comments:</p>
<ol>
<li><strong> Hotline Number: 01125527757</strong></li>
<li><strong>Email:emeturner12@gmail.com</strong></li>
</ol>

<br><br><br>
</body>
</html>
